using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;

public class IndexModel : PageModel
{
    private readonly HttpClient _httpClient;

    [BindProperty]
    public string Name { get; set; } = string.Empty;

    [BindProperty]
    public string MSSV { get; set; } = string.Empty;

    [BindProperty]
    public string Coordinates { get; set; } = string.Empty;

    [BindProperty]
    public string LatDifference { get; set; } = string.Empty;

    [BindProperty]
    public string LonDifference { get; set; } = string.Empty;

    public IndexModel(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public void OnGet()
    {
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }

        // Gửi dữ liệu đến Google Sheets
        var response = await _httpClient.PostAsync("https://script.google.com/macros/s/AKfycbzVktM1TS1nezvY2_NpDDhtacDFgl09H_xavSMaN537DzCY1lfPNhv9kLB1pW6bjokZ/exec",
            new FormUrlEncodedContent(new Dictionary<string, string>
            {
                { "name", Name ?? string.Empty },
                { "mssv", MSSV ?? string.Empty },
                { "coordinates", Coordinates ?? string.Empty },
                { "latDifference", LatDifference ?? string.Empty },
                { "lonDifference", LonDifference ?? string.Empty }
            }));

        // Kiểm tra phản hồi
        if (response.IsSuccessStatusCode)
        {
            return Page();
        }
        else
        {
            ModelState.AddModelError(string.Empty, "Lỗi khi gửi dữ liệu");
            return Page();
        }
    }
}
